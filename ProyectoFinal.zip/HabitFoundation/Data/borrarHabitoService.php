<?php
	header('Accept: application/json');
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "HabitFoundation";
	
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	if ($conn -> connect_error) 
	{
	    header('HTTP/1.1 500 Bad connection to Database');
	    die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		$habitname = $_POST['habitname'];
		$habituser = $_POST['userhabit'];

		$sql = "DELETE FROM Habits WHERE habitname = '$habitname' AND habituser = '$habituser'";	

		if(mysqli_query($conn, $sql))
		{
			//echo "SUCCESS";
		}
		else
		{
    			//echo "ERROR";
		}
	}
/*
	else
	{	
		$habitname = $_POST['habitname'];
		$habituser = $_POST['userhabit'];

		$sql = "DELETE FROM Habits WHERE habitname = '$habitname' AND habituser = '$habituser'";
	
	if (mysqli_query($conn, $sql)) {
		echo json_encode($habitname);
} else {
    		echo "Error deleting record: " . $conn->error;
		}

$conn->close();
*/
?>
