<?php
	header('Accept: application/json');
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "HabitFoundation";

	$conn = new mysqli($servername, $username, $password, $dbname);

	if ($conn -> connect_error)
	{
		header("HTTP/1.1 500 Bad Connection to the DataBase");
		die("The server is down, please try again later.");
	}
	else
	{
		$uName = $_POST["uName"];
		$uPassword = $_POST["uPassword"];

		$sql = "SELECT username, passwrd FROM Users WHERE username = '$uName' AND passwrd = '$uPassword'";
		
		$result = $conn -> query($sql);

		if ($result -> num_rows > 0)
		{
			// Guardar cookie
			$remember = $_POST["remember"];
			if ($remember == "true")
			{
			setcookie("username", $uName, time() + 3600*24*20, "/");
			}
			// Abrir y guardar datos en la sesion
				session_start();

				$_SESSION["username"] = $uName;

			while($row = $result -> fetch_assoc())
			{
				$response = $row["username"];
			}
			echo json_encode($response);
		}
		else
		{
			header("HTTP/1.1 406 User not found");
			die("Wrong credentials provided.");
		}
	}

?>
