<?php
	header('Content-type: application/json');

	session_start();
	if (isset($_SESSION["username"]))
	{
		echo json_encode(array("username" => $_SESSION["username"]));
	}
	else
	{
		header('HTTP/1.1 406 Session has expired.');
	}

?>