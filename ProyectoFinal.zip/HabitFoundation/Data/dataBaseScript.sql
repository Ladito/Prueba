CREATE TABLE Users (
    	
	username VARCHAR(30) NOT NULL PRIMARY KEY,
    	
	passwrd VARCHAR(30) NOT NULL
);


CREATE TABLE Habits (
	
	habitname VARCHAR(30) NOT NULL,
	
	frequency VARCHAR(30) NOT NULL,
	
	description VARCHAR(150) NOT NULL,
	
	habituser VARCHAR(30) NOT NULL

);


CREATE TABLE Groups (
    
	groupname VARCHAR(30) NOT NULL,
    
	groupuser VARCHAR(30) NOT NULL

);


INSERT INTO Users(username, passwrd)

VALUES  ('luis', 'diaz'),
	   ('java', 'java');
		

INSERT INTO Habits(habitname, frequency, description, habituser)

VALUES ('Drink Water', '2 times per week', 'Drink 3 liters of water per day', 'luis'),

('JavaDava', '3 times per week', 'Ladrar 20 minutos.' , 'java');