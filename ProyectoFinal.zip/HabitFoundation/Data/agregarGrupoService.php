<?php
	header('Accept: application/json');
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "HabitFoundation";

	$conn = new mysqli($servername, $username, $password, $dbname);

	if ($conn -> connect_error)
	{
		header("HTTP/1.1 500 Bad Connection to the DataBase");
		die("The server is down, please try again later.");
	}
	else
	{
		$uName = $_POST["uName"];
		$uGroup = $_POST["groupname"];

		$sql = "INSERT INTO Groups (groupname, groupuser) VALUES ('$uGroup', '$uName')";

		if(mysqli_query($conn, $sql))
		{
			echo json_encode($uGroup);
		}
		else
		{
			header("HTTP/1.1 406 Habits not found");
			die("Please contact tech support.");
		}
	}

?>
