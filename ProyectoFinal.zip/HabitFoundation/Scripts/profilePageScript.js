$(document).ready(function(){

	$.ajax({
		url : "data/sessionService.php",
		type : "GET",
		dataType : "json",
		success : function(sessionJson){
			$("#username").val(sessionJson.username);
			$("#greetings").append($("#username").val());
			Materialize.updateTextFields();
		},
		error : function(errorMessage){
			window.replace.location("mainPage.html");
		}
	});

	$(".button-collapse").sideNav();
	$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrainWidth: false,
      hover: true,
      gutter: 0,
      belowOrigin: true,
      alignment: 'left',
      stopPropagation: false
    });
	$('select').material_select();

		//CARGAR HABITOS

	var jsonObject = {
		"uName" : $("#username").val()
	}

	$.ajax({
		url : "data/cargarHabitosService.php",
		type : "POST",
		dataType : "json",
		data: jsonObject,
		success : function(habitos){
			
			var agregarhtml = "";

			for(var i = 0; i < habitos.length; i++)
			{
				agregarhtml += '<div class="card brown darken-3" id="delete' + i + '"' + 'habitname="'+habitos[i].habitname + '">' +
						'<div class="card-content white-text">' +
						'<span class="card-title">' + habitos[i].habitname + '</span>' +
						'<p>Frequency: ' + habitos[i].frequency + '</p>' +
						'<p>Description: ' + habitos[i].description + '</p>' +
						'</div>' + '<div class="card-action">' + '<a class="red deleter btn" remover="delete' + i + '">Delete</a>' + '</div>' + '</div>';

			}
			$("#habitos").append(agregarhtml);
		$(".deleter").on("click", function(){
		var attribute = $(this).attr("remover");
		var habitname = $('#'+attribute).attr("habitname");

		var jsonHabit = {
			"habitname" : habitname,
			"userhabit" : $("#username").val()
		}
		$.ajax({
			url : "data/borrarHabitoService.php",
			type : "POST",
			dataType : "json",
			data: jsonHabit,
			success : function(){
				Materialize.toast("Habito " + jsonHabit["habitname"] + " borrado exitosamente.", 4000, 'rounded');
			},
			error : function(errorMessage){
				Materialize.toast("Habito " + jsonHabit["habitname"] + " borrado exitosamente.", 4000, 'rounded');
			}
		});		
			$('#'+attribute).remove();
		});
		},
		error : function(errorMessage){
			$.ajax(this);
			console.log(errorMessage.responseText);
		}

	});


	$("#add").on("click",function(){

	habitData = {
		"habitname" : $("#habitname").val(),
		"frequency" : $("#frequency").val(),
		"description" : $("#description").val(),
		"userhabit" : $("#username").val()
	}

	$.ajax({
		url : "data/agregarHabitoService.php",
		type : "POST",
		dataType : "json",
		data : habitData,
		success : function(sessionJson){
			location.reload();
		},
		error : function(errorMessage){
			console.log(errorMessage);
		}
	});
	});

	$.ajax({
		url : "data/cargarGruposService.php",
		type : "GET",
		dataType : "json",
		success : function(grupos){
			
			var agregarhtml;

			for(var i = 0; i < grupos.length; i++)
			{
				groupName = {
					"groupName" : grupos[i].groupName
				}
				agregarhtml = "";
				$.ajax({
				url : "data/cargarMiembrosService.php",
				type : "POST",
				dataType : "json",
				data : groupName,
				success : function(miembros){
					agregarhtml += '<div class="card brown darken-3">' +
						'<div class="card-content white-text">' +
						'<span class="card-title">' +
groupName["groupName"] + '</span>' + '<p>Members:</p>';
					for(var j=0;j<miembros.length; j++)
					{
			agregarhtml += '<p>'+miembros[j].name + '</p>';
					}
				agregarhtml+='</div>' + '</div>';				$("#grupos").append(agregarhtml);
				},
				error : function(errorMessage){
					console.log(errorMessage);
				}
				});
			}
		},
		error : function(errorMessage){
			console.log(errorMessage);
		}
	});

	$("#join").on("click",function(){

		groupData = {
			"groupname" : $("#nameg").val(),
			"uName" : $("#username").val()
		}

		$.ajax({
			url : "data/agregarGrupoService.php",
			type : "POST",
			dataType : "json",
			data : groupData,
			success : function(sessionJson){
				location.reload();
			},
			error : function(errorMessage){
				console.log(errorMessage);
			}
		});

	});

		//LOGOUT

	$(".logout").on("click",function(){
		$.ajax({
			url : "data/deleteSession.php",
			type : "GET",
			dataType : "json",
			success : function(successMessage){
				window.replace.location("mainPage.html");
			},
			error : function(errorMessage){
				window.replace.location("mainPage.html");
			}
		});
	});


});