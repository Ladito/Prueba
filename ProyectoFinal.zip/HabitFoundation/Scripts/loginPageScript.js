$(document).ready(function(){
	$(".button-collapse").sideNav();
	$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrainWidth: false,
      hover: true,
      gutter: 0,
      belowOrigin: true,
      alignment: 'left',
      stopPropagation: false
    });


	// Accion para cargar las cookies previamente guardadas
	$.ajax({
		url : "data/cookieService.php",
		type : "GET",
		dataType : "json",
		success : function(cookieJson){
			$("#username").val(cookieJson.username);
			Materialize.updateTextFields();
		},
		error : function(errorMessage){
			console.log(errorMessage.responseText);
		}

	});


     $("#loginButton").on("click", function(){

		var rememberMe = $("#rememberMe").is(":checked");

           var jsonObject = {
           	"uName" : $("#username").val(),
			"uPassword" : $("#userpassword").val(),
			"remember" : rememberMe
           };

     $.ajax({
           type: "POST",
           url: "data/loginService.php",
           dataType: "json",
           data: jsonObject,
           contentType: 'application/x-www-form-urlencoded',
           success: function(jsonRecieved) {
			window.location.replace("profilePage.html");
			Materialize.toast("Bienvenido de vuelta " + 				jsonRecieved, 3000, 'rounded');
           },
           error: function(errorMsg){
                alert(errorMsg.statusText);
           }
	});
     });
});