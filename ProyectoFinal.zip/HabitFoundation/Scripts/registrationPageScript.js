$(document).ready(function(){
	$(".button-collapse").sideNav();
	$('.parallax').parallax();
	$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrainWidth: false,
      hover: true,
      gutter: 0,
      belowOrigin: true,
      alignment: 'left',
      stopPropagation: false
    });

	$("#registerButton").on("click", function(){

		var rememberMe = $("#rememberMe").is(":checked");

                var jsonObject = {
                    "username" : $("#username").val(),
                    "userPassword" : $("#userpassword").val(),
			    "remember" : rememberMe
                };

                $.ajax({
                    type: "POST",
                    url: "data/registrationService.php",
                    dataType: "json",
                    data: jsonObject,
                    contentType: 'application/x-www-form-urlencoded',
                    success: function(jsonData) {
				Materialize.toast("Cuenta creada exitosamente. Bienvenido " + $("#usernamer").val() + "!", 4000, 'rounded');
                        window.location.replace("profilePage.html");
                       
                    },
                    error: function(errorMsg){
                        alert(errorMsg.statusText);
                    }
                });
           });


});